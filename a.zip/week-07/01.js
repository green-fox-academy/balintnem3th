var myName = 'myNameIsMyName'
console.log(myName);