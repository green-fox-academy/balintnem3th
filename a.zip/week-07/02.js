// Modify this program to console.log Humpty Dumpty riddle correctly
var third = ('All the king\'s horses and all the king\'s men \n');
var second = ('Humpty Dumpty had a great fall. \n');
var first = ('Humpty Dumpty sat on a wall, \n');
var fourth = ('Couldn\'t put Humpty together again. \n');

console.log(first + second + third+ fourth)