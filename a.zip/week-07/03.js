var third = 'Esther! ';
var second = 'Mary! ';
var first = 'Joe! ';
var greets = [first,second,third].map(function(name){
        return ('Hello ' + name)
});

for (var j = 0; j < greets.length; j++) {
    console.log(greets[j]); 
  }
