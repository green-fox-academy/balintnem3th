var lineCount = 6;

function draw(lines){
    for (var j = 0; j < lines; j++){
        if(j==0 || j == lines-1)
        {
            drawFirst(lines);
        }
        else{
            drawOthers(lines)
        } 
    }  
}

function drawFirst(line){
    for (var j = 0; j < line; j++){
        console.log('*');
    }
}

function drawOthers(line){
    for (var j = 0; j < line; j++){
        if(j==0 || j==line-1)
        {
        console.log('*');
        }
        else
        {
        console.log(' ') ;
        } 
    }    
}

draw(lineCount);



